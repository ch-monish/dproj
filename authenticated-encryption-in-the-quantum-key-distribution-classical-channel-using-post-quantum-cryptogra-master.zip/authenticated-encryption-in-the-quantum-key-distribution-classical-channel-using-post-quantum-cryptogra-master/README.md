## Description
QuNetSim is a simulator that performs common quantum networking tasks. The Authenticated Encryption Scheme using NTRU and Falcon are integrated into the QuNetSim for checking the compatibility of our algorithm. QuNetSim uses two communication parties Alice and Bob. The default quantum bit transmission rate is set to 200. We can change it to any number depending on our requirements.

## Execution Steps
### 1. Install Python 3.x on your system
* sudo apt install python3.8
* python --version


### 2. Dependencies required for NTRU 
* Install Packages SymPy, NumPy and docopt
* pip3 install --user sympy
* pip3 install --user numpy
* pip3 install --user docopt


### 3. Dependencies required for Falcon
* 	Install pyprof2calltree and kcachegrind on your machine
* 	pip install pyprof2calltree 
* 	sudo apt install kcachegrind


### 4. Install QKD simulator QuNetSim on your system 
*  	pip install qunetsim

