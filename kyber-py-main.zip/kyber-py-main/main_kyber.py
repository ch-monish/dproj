from kyber import Kyber1024

pk, sk = Kyber1024.keygen()
c, key = Kyber1024.enc(pk)
_key = Kyber1024.dec(c, sk)
print(pk, sk)
print("cipher text", c)
print("key", key)
print("decrtpted value", _key)
